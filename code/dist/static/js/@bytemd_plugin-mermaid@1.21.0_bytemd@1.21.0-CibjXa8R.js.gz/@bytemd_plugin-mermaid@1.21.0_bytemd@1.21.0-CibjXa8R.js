const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["static/js/mermaid@10.9.3-CxEwO8Ge.js","static/js/dayjs@1.11.13-DXimfR00.js","static/js/@braintree_sanitize-url@6.0.4-BB1FEM6a.js","static/js/d3-transition@3.0.1_d3-selection@3.0.0-B83X84Tf.js","static/js/d3-dispatch@3.0.1-kxCwF96_.js","static/js/d3-timer@3.0.1-DdKHrDhs.js","static/js/d3-interpolate@3.0.1-DolQLDPq.js","static/js/d3-color@3.1.0-amxIadob.js","static/js/d3-selection@3.0.0-C52G7wmG.js","static/js/d3-ease@3.0.1-DRPgKoYJ.js","static/js/d3-zoom@3.0.0-BZGMUjlT.js","static/js/dompurify@3.1.6-B551CwFq.js","static/js/dagre-d3-es@7.0.10-Dde9l707.js","static/js/lodash-es@4.17.21-D6PnhKvy.js","static/js/d3-shape@3.2.0-U0HymUHV.js","static/js/d3-path@3.1.0-CimkQT29.js","static/js/d3-fetch@3.0.1-BOsq7VnW.js","static/js/khroma@2.1.0-DUX6PT6k.js","static/js/uuid@9.0.1-DhYbOkY1.js","static/js/d3-scale@4.0.2-WQ2vdn9f.js","static/js/internmap@2.0.3-BkD7Hj8s.js","static/js/d3-array@3.2.4-DGRYoJHh.js","static/js/d3-format@3.1.0-CzD4bSOQ.js","static/js/d3-time-format@4.1.0-DJZxj2s6.js","static/js/d3-time@3.1.0-DO1oJ2A5.js","static/js/d3-axis@3.0.0-DSWTncID.js","static/js/elkjs@0.9.3-BIFS35Ym.js","static/js/cytoscape@3.30.3-YXkLVt_w.js","static/js/cytoscape-cose-bilkent@4.1.0_cytoscape@3.30.3-BU78DwU9.js","static/js/cose-base@1.0.3-Dh2GXGPk.js","static/js/layout-base@1.0.2-CB42RYg0.js","static/js/d3-sankey@0.12.3-D20wQ1B0.js","static/js/d3-array@2.12.1-CpYDW9jx.js","static/js/d3-shape@1.3.7-Dr-m8Vax.js","static/js/d3-path@1.0.9-BevWroqt.js","static/js/d3-scale-chromatic@3.1.0-B-NsZVaP.js","static/js/@bytemd_plugin-math@1.21.0_bytemd@1.21.0-Dc_JUVYX.js","static/js/remark-math@5.1.1-C8vps_rM.js","static/js/micromark-extension-math@2.1.2-StTlgfH1.js","static/js/micromark-factory-space@1.1.0-C57A7NS2.js","static/js/micromark-util-character@1.2.0-D-NaLusr.js","static/js/katex@0.16.11-CvgdMzdh.js","static/js/mdast-util-math@2.0.2-Boy2OOKg.js","static/js/longest-streak@3.1.0-BHNUWYJP.js","static/js/mdast-util-to-markdown@1.5.0-D9VzXa1u.js","static/js/micromark-util-decode-string@1.1.0-CdHYbWAu.js","static/js/decode-named-character-reference@1.0.2-C3-224fz.js","static/js/micromark-util-decode-numeric-character-reference@1.1.0-DRnCnno4.js","static/js/ts-dedent@2.2.0-DrFu-skq.js","static/js/stylis@4.3.4-OW4gUFyn.js","static/js/mdast-util-from-markdown@1.3.1-Ch0ocoA0.js","static/js/micromark@3.2.0-BlNIu7Zp.js","static/js/micromark-util-combine-extensions@1.1.0-B4FRL3HR.js","static/js/micromark-util-chunked@1.1.0-DrRIdSP-.js","static/js/micromark-core-commonmark@1.1.0-DsNB-gXs.js","static/js/micromark-util-classify-character@1.1.0-Bznx_M8a.js","static/js/micromark-util-resolve-all@1.1.0-PQCKh0dx.js","static/js/micromark-util-subtokenize@1.1.0-Bno4aDYn.js","static/js/micromark-factory-destination@1.1.0-CIDBLnlA.js","static/js/micromark-factory-label@1.1.0-DLDreeYE.js","static/js/micromark-factory-title@1.1.0-Tund6-WB.js","static/js/micromark-factory-whitespace@1.1.0-h7AOC73-.js","static/js/micromark-util-normalize-identifier@1.1.0-C9ANKk3v.js","static/js/micromark-util-html-tag-name@1.2.0-DbKNfynz.js","static/js/unist-util-stringify-position@3.0.3-Ch_qCilz.js","static/js/mdast-util-to-string@3.2.0-C_aolqmU.js"])))=>i.map(i=>d[i]);
import{_ as u}from"./@bytemd_plugin-math@1.21.0_bytemd@1.21.0-Dc_JUVYX.js";const g={ChartGraph:'<svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 48 48"><path stroke="currentColor" stroke-linejoin="round" stroke-width="4" d="M17 6h14v9H17zM6 33h14v9H6zM28 33h14v9H28z"/><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="4" d="M24 16v8M13 33v-9h22v9"/></svg>'},p="Entity relationship diagram",w="Flow chart",M="Gantt chart",k="Mermaid diagrams",v="Mindmaps",S="Pie chart",D="Sequence diagram",f="State diagram",A="Timeline",E="User journey diagram",y={class:"Class diagram",er:p,flowchart:w,gantt:M,mermaid:k,mindmap:v,pie:S,sequence:D,state:f,timeline:A,uj:E};function I({locale:d,...l}={}){const e={...y,...d};let n;const h=[{title:e.flowchart,code:`graph TD
Start --> Stop`},{title:e.sequence,code:`sequenceDiagram
Alice->>John: Hello John, how are you?
John-->>Alice: Great!
Alice-)John: See you later!`},{title:e.class,code:`classDiagram
Animal <|-- Duck
Animal <|-- Fish
Animal <|-- Zebra
Animal : +int age
Animal : +String gender
Animal: +isMammal()
Animal: +mate()
class Duck{
+String beakColor
+swim()
+quack()
}
class Fish{
-int sizeInFeet
-canEat()
}
class Zebra{
+bool is_wild
+run()
}`},{title:e.state,code:`stateDiagram-v2
[*] --> Still
Still --> [*]

Still --> Moving
Moving --> Still
Moving --> Crash
Crash --> [*]`},{title:e.er,code:`erDiagram
CUSTOMER ||--o{ ORDER : places
ORDER ||--|{ LINE-ITEM : contains
CUSTOMER }|..|{ DELIVERY-ADDRESS : uses`},{title:e.uj,code:`journey
title My working day
section Go to work
Make tea: 5: Me
Go upstairs: 3: Me
Do work: 1: Me, Cat
section Go home
Go downstairs: 5: Me
Sit down: 5: Me`},{title:e.gantt,code:`gantt
title A Gantt Diagram
dateFormat  YYYY-MM-DD
section Section
A task           :a1, 2014-01-01, 30d
Another task     :after a1  , 20d
section Another
Task in sec      :2014-01-12  , 12d
another task      : 24d`},{title:e.pie,code:`pie title Pets adopted by volunteers
"Dogs" : 386
"Cats" : 85
"Rats" : 15`},{title:e.mindmap,code:`mindmap
      Root
          A
            B
            C
    `},{title:e.timeline,code:`timeline
      title History of Social Media Platform
      2002 : LinkedIn
      2004 : Facebook
           : Google
      2005 : Youtube
      2006 : Twitter
      `}];return{viewerEffect({markdownBody:r}){(async()=>{const a=r.querySelectorAll("pre>code.language-mermaid");a.length!==0&&(n||(n=await u(()=>import("./mermaid@10.9.3-CxEwO8Ge.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65])).then(t=>t.default),l&&n.initialize(l)),a.forEach((t,c)=>{const o=t.parentElement,s=t.innerText,i=document.createElement("div");i.classList.add("bytemd-mermaid"),i.style.lineHeight="initial",o.replaceWith(i),n.render(`bytemd-mermaid-${Date.now()}-${c}`,s,i).then(m=>{i.innerHTML=m.svg}).catch(m=>{})}))})()},actions:[{title:e.mermaid,icon:g.ChartGraph,cheatsheet:"```mermaid",handler:{type:"dropdown",actions:h.map(({title:r,code:a})=>({title:r,handler:{type:"action",click({editor:t,appendBlock:c,codemirror:o}){const{line:s}=c("```mermaid\n"+a+"\n```");t.setSelection(o.Pos(s+1,0),o.Pos(s+a.split(`
`).length)),t.focus()}}})),...e}}]}}const $="关系图",C="流程图",R="甘特图",G="Mermaid图表",T="思维导图",b="饼状图",j="时序图",q="状态图",_="时间轴",H="旅程图",P={class:"类图",er:$,flowchart:C,gantt:R,mermaid:G,mindmap:T,pie:b,sequence:j,state:q,timeline:_,uj:H};export{I as m,P as z};
